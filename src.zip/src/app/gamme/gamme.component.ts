import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UserapiService } from '../services/userapi.service';
import { Produits } from '../interfaces/produits';

@Component({
  selector: 'app-gamme',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './gamme.component.html',
  styleUrls: ['./gamme.component.css']
})
export class GammeComponent implements OnInit {
  produits: Produits[] = [];
  gammes: string[] = ['Electrique', 'Essence', 'Diesel', 'Hybride'];
  gammeSelectionnee: string = 'Hybride';

  constructor(private userapiService: UserapiService) {}

  ngOnInit() {
    this.produits = this.userapiService.getProduits();
  }

  filtrerParGamme(gamme: string) {
    this.gammeSelectionnee = gamme;
  }

  getProduitsFiltres(): Produits[] {
    return this.produits.filter(p => p.gamme === this.gammeSelectionnee);
  }
}