import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GammeComponent } from './gamme.component';
import { UserapiService } from '../services/userapi.service';
import { Produits } from '../interfaces/produits';
import { of } from 'rxjs';

describe('GammeComponent', () => {
  let component: GammeComponent;
  let fixture: ComponentFixture<GammeComponent>;
  let mockUserapiService: jasmine.SpyObj<UserapiService>;

  const mockProduits: Produits[] = [
    {
      id: 1,
      modele: 'BMW M440i',
      puissance: '374 ch',
      gamme: 'Essence',
      prix: 68400,
      quantite: 1,
      image: 'image1.jpg',
      boite: 'Automatique'
    },
    {
      id: 2,
      modele: 'BMW i4',
      puissance: '340 ch',
      gamme: 'Electrique',
      prix: 55000,
      quantite: 1,
      image: 'image2.jpg',
      boite: 'Automatique'
    },
    {
      id: 3,
      modele: 'BMW X5 Hybride',
      puissance: '394 ch',
      gamme: 'Hybride',
      prix: 75000,
      quantite: 1,
      image: 'image3.jpg',
      boite: 'Automatique'
    }
  ];

  beforeEach(async () => {
    mockUserapiService = jasmine.createSpyObj('UserapiService', ['getProduits']);
    mockUserapiService.getProduits.and.returnValue(mockProduits);

    await TestBed.configureTestingModule({
      imports: [GammeComponent],
      providers: [
        { provide: UserapiService, useValue: mockUserapiService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(GammeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with produits from service', () => {
    expect(component.produits.length).toBe(3);
    expect(mockUserapiService.getProduits).toHaveBeenCalled();
  });

  it('should have initial gamme selection as Hybride', () => {
    expect(component.gammeSelectionnee).toBe('Hybride');
  });

  it('should have all gammes defined', () => {
    expect(component.gammes).toEqual(['Electrique', 'Essence', 'Diesel', 'Hybride']);
  });

  it('should filter produits by selected gamme', () => {
    component.gammeSelectionnee = 'Electrique';
    const filtered = component.getProduitsFiltres();
    expect(filtered.length).toBe(1);
    expect(filtered[0].modele).toBe('BMW i4');
  });

  it('should change selected gamme', () => {
    component.filtrerParGamme('Essence');
    expect(component.gammeSelectionnee).toBe('Essence');
  });

  it('should return empty array when no produits in gamme', () => {
    component.gammeSelectionnee = 'Diesel';
    const filtered = component.getProduitsFiltres();
    expect(filtered.length).toBe(0);
  });

  it('should display correct number of produits for each gamme', () => {
    component.gammeSelectionnee = 'Essence';
    expect(component.getProduitsFiltres().length).toBe(1);

    component.gammeSelectionnee = 'Electrique';
    expect(component.getProduitsFiltres().length).toBe(1);

    component.gammeSelectionnee = 'Hybride';
    expect(component.getProduitsFiltres().length).toBe(1);
  });
});