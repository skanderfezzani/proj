import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Home/home.component';
import { ProduitComponent } from './produit/produit.component';
import { AjoutComponent } from './ajouter/ajouter.component';
import { LoginComponent } from './guards/login/login.component';
import { InscriptionComponent } from './guards/inscription/inscription.component';
import { GammeComponent } from './gamme/gamme.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'produits', component: ProduitComponent },
  { path: 'ajouter', component: AjoutComponent },
  { path: 'login', component: LoginComponent },
  { path: 'inscription', component: InscriptionComponent },
  { path: 'gamme', component: GammeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }