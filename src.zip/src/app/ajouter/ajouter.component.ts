import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Produits } from '../interfaces/produits';
import { UserapiService } from '../services/userapi.service';

@Component({
  selector: 'app-ajout',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ajouter.component.html',
})
export class AjoutComponent {
  nouveauProduit: Produits = {
    id: 0,
    modele: '',
    puissance: '',
    gamme: '',
    prix: 0,
    quantite: 1,
    image: '',
    boite: ''
  };

  constructor(private userapiService: UserapiService) {}

  ajouterProduit() {
    if (this.nouveauProduit.modele && this.nouveauProduit.puissance && 
        this.nouveauProduit.gamme && this.nouveauProduit.prix > 0) {
      
      this.userapiService.ajouterProduit({...this.nouveauProduit});
      
      this.nouveauProduit = {
        id: 0, 
        modele: '', 
        puissance: '', 
        gamme: '', 
        prix: 0, 
        quantite: 1, 
        image: '', 
        boite: ''
      };
      
      alert('Produit ajouté avec succès !');
    } else {
      alert('Veuillez remplir tous les champs.');
    }
  }
}