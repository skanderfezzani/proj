import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { UserapiService } from '../../services/userapi.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inscription',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './inscription.component.html',
  styleUrls: ['./inscription.component.css']
})
export class InscriptionComponent {
  inscriptionForm: FormGroup;

  constructor(private fb: FormBuilder, private userApi: UserapiService, private router: Router) {
    this.inscriptionForm = this.fb.group({
      prenom: ['', [Validators.required]],
      nom: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    if (this.inscriptionForm.valid) {
      if (this.userApi.emailExists(this.inscriptionForm.value.email)) {
        alert('Email déjà utilisé !');
        return;
      }

      this.userApi.addUser(this.inscriptionForm.value);
      alert('Inscription réussie !');
      this.router.navigate(['/login']);
    } else {
      alert('Formulaire invalide !');
    }
  }
}