import { Injectable } from '@angular/core';
import { Produits } from '../interfaces/produits';

export interface User {
  prenom: string;
  nom: string;
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserapiService {
  private users: User[] = []; 
  private produits: Produits[] = [];

  constructor() { }

  addUser(user: User): void {
    this.users.push(user);
  }

  emailExists(email: string): boolean {
    return this.users.some(u => u.email === email);
  }

  getUsers(): User[] {
    return this.users;
  }

  findUser(email: string, password: string): User | undefined {
    return this.users.find(u => u.email === email && u.password === password);
  }

  ajouterProduit(produit: Produits): void {
    produit.id = this.produits.length + 1;
    this.produits.push({...produit});
  }

  getProduits(): Produits[] {
    return this.produits;
  }

  getProduitById(id: number): Produits | undefined {
    return this.produits.find(p => p.id === id);
  }

  supprimerProduit(id: number): void {
    this.produits = this.produits.filter(p => p.id !== id);
  }
}