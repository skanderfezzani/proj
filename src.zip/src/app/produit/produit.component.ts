import { Component, Input } from '@angular/core';
import { Produits } from '../interfaces/produits';
@Component({
  selector: 'app-produit',
  template: `
    <div class="produit-card">
      <img [src]="produit.image" alt="{{ produit.modele }}" width="200">
      <h3>{{ produit.modele }}</h3>
      <p>Puissance: {{ produit.puissance }}</p>
      <p>Boîte: {{ produit.boite }}</p>
      <p>Prix: {{ produit.prix }} Dt</p>
      <p *ngIf="produit.nprix">Ancien prix: {{ produit.nprix }} Dt</p>
      <p>Gamme: {{ produit.gamme }}</p>
      <p *ngIf="produit.autonomie">Autonomie: {{ produit.autonomie }}</p>
    </div>
  `,
  styles: [`
    .produit-card {
      border: 1px solid #ccc;
      padding: 10px;
      margin: 10px;
      display: inline-block;
      vertical-align: top;
    }
  `]
})

export class ProduitComponent {
 @Input() produit!: Produits;
}
