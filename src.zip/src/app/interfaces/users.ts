export interface Users {
fullname: string;
email: string;
password: string;
profile?: string;
}
