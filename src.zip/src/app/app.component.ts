import { Component } from '@angular/core';
import { HomeComponent } from './Home/home.component'; 
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule } from '@angular/router';
import { OccasionComponent } from './occasion/occasion.component';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HomeComponent,NavbarComponent,RouterModule,OccasionComponent], 
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-app';
}