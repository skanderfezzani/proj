import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProduitComponent } from '../produit/produit.component';
import { Users } from '../interfaces/users';
import { Produits } from '../interfaces/produits';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-occasion',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './occasion.component.html',
  styleUrl: './occasion.component.css'
})
export class OccasionComponent {
  id!:number;
  recevoirId(message: number) {
  this.id = message;
  }
  produit:Produits={
        image: "https://www.motorlegend.com/images-voiture/med/bmw-serie-4-g22-coupe-m440i-xdrive-374-ch-130492.jpg",
        quantite: 1,
        modele: "BMW M440i Coupe",
        puissance: "374 ch (275 kW)",
        boite: "Boite de vitesses automatique Sport avec palettes au volant",
        prix: 68400,
        nprix: 52000,
        gamme: "Essence",
        id: 1
      };
  
  produits:Produits[]=[
      {
        image: "https://www.motorlegend.com/images-voiture/med/bmw-serie-4-g22-coupe-m440i-xdrive-374-ch-130492.jpg",
        quantite: 1,
        modele: "BMW M440i Coupe",
        puissance: "374 ch (275 kW)",
        boite: "Boite de vitesses automatique Sport avec palettes au volant",
        prix: 68400,
        nprix: 52000,
        gamme: "Essence",
        id: 1
      },
      {
        image: "https://i.f1g.fr/media/figarofr/704x/2014/01/13/PHO8bebc984-7c3d-11e3-89b5-127f77cabfb0-300x200.jpg",
        quantite: 1,
        modele: "BMW 518d",
        puissance: "150 ch (110 kW)",
        boite: "Boîte de vitesses automatique",
        prix: 49000,
        nprix: 39000,
        gamme: "Essence",
        id: 20
      },
      {
        image: "https://www.largus.fr/images/photos/rsi/_G_JPG/Voitures/BMW/Serie_6_Gran_Turismo/I/Ph1/Berline_5_portes/troisquartarriere4.jpg",
        quantite: 1,
        modele: "BMW 620d",
        prix: 65250,
        nprix: 41000,
        puissance: "190 ch (140 kW)",
        boite: "Automatique",
        gamme: "Diesel",
        id: 3
      },
      {
        image: "https://sf1.autojournal.fr/wp-content/uploads/autojournal/2020/10/BMW_Serie_7_2019_74e81.jpg",
        quantite: 1,
        modele: "BMW 730d",
        puissance: "286 ch (210 kW)",
        boite: "Automatique",
        prix: 100750,
        nprix: 50000,
        gamme: "Diesel",
        id: 4
      },
      
    ]

}
